README.txt para e-Voting
Autores:
Ana Luísa da Rocha Alves Rainha Coelho
2015231777
Maria Paula de Alencar Viegas
2017125592

Como correr o código:
No ide correr as classes: RMIServer.java (port:7000)
Criar Aplicação tomcat local: HTTP Port: 8080 || JMX port: 1099
		  
		  
 