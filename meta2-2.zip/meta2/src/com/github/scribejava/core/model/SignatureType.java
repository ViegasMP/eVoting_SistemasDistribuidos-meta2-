package com.github.scribejava.core.model;

public enum SignatureType {

    Header,
    QueryString
}
